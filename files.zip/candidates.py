"""Candidates route — GET skills and full profile."""
from fastapi import APIRouter, Depends, HTTPException
from api.dependencies import verify_api_key

router = APIRouter(prefix="/api/v1", tags=["Candidates"])


@router.get("/candidates/{candidate_id}/skills", summary="Get candidate's normalized skill profile")
async def get_candidate_skills(candidate_id: str, _: str = Depends(verify_api_key)):
    from api.routes.match import get_candidate
    c = get_candidate(candidate_id)
    by_cat: dict = {}
    for s in c.skills:
        cat = s.category or "Uncategorized"
        by_cat.setdefault(cat, []).append(s.canonical_name or s.raw_name)
    return {
        "candidate_id":          c.id,
        "full_name":             c.full_name,
        "total_skills":          len(c.skills),
        "total_years_experience": c.total_years_experience,
        "seniority_level":       c.seniority_level,
        "skills_by_category":    by_cat,
        "skills":                [s.model_dump() for s in c.skills],
    }


@router.get("/candidates/{candidate_id}", response_model=None, summary="Get full candidate profile")
async def get_candidate_full(candidate_id: str, _: str = Depends(verify_api_key)):
    from api.routes.match import get_candidate
    return get_candidate(candidate_id)
