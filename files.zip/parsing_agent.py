"""
Parsing Agent
=============
Extracts raw text from PDF / DOCX / plain-text resumes, then uses an LLM
to structure the content into a ParsedResume object.

Pipeline:
  file bytes  ->  [text extractor]  ->  raw text
              ->  [LLM structurer]  ->  ParsedResume JSON
              ->  [validator]       ->  ParsedResume model
"""

import io
import json
import re
import time
import logging
from pathlib import Path
from typing import Optional, Tuple, List

import pdfplumber
import fitz                          # PyMuPDF fallback PDF extractor
import anthropic
from docx import Document as DocxDocument

from core.config import get_settings
from models.resume import (
    ParsedResume, WorkExperience, Education, ExtractedSkill,
    Certification, Project, FileFormat, ProficiencyLevel,
)

logger = logging.getLogger(__name__)
settings = get_settings()


EXTRACTION_SYSTEM_PROMPT = """You are an expert resume parser. Given raw resume text, extract 
structured information and return ONLY a valid JSON object with NO additional text or markdown.

Return this exact JSON structure:
{
  "full_name": "",
  "email": "",
  "phone": "",
  "location": "",
  "linkedin_url": "",
  "github_url": "",
  "portfolio_url": "",
  "summary": "",
  "total_years_experience": null,
  "work_experience": [
    {
      "company": "",
      "role": "",
      "start_date": "",
      "end_date": "",
      "duration_months": null,
      "responsibilities": [],
      "technologies": []
    }
  ],
  "education": [
    {
      "institution": "",
      "degree": "",
      "field": "",
      "year": null,
      "gpa": null
    }
  ],
  "skills": [
    {
      "raw_name": "",
      "proficiency": null,
      "years_experience": null,
      "context_snippet": ""
    }
  ],
  "certifications": [
    {
      "name": "",
      "issuer": "",
      "year": null,
      "expiry_year": null
    }
  ],
  "projects": [
    {
      "name": "",
      "description": "",
      "technologies": [],
      "url": null
    }
  ],
  "publications": [],
  "languages": []
}

Rules:
- Extract ALL skills mentioned anywhere in the resume (technical and soft skills)
- For each skill include the surrounding sentence as context_snippet (max 120 chars)
- Infer proficiency from context: expert in / 5+ years -> expert; familiar with -> familiar
- Calculate duration_months from start/end dates when possible
- Estimate total_years_experience from work history
- Use null for missing numeric fields, empty string for missing text fields
- proficiency values: beginner | familiar | intermediate | advanced | expert | null
- Return ONLY the JSON, no markdown, no explanation"""

EXTRACTION_USER_PROMPT = "Parse this resume and return structured JSON:\n\n{raw_text}"


# ── Text Extractors ───────────────────────────────────────────────────────────

def extract_text_from_pdf(file_bytes: bytes) -> Tuple[str, List[str]]:
    warnings: List[str] = []
    text = ""
    try:
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            pages = []
            for page in pdf.pages:
                page_text = page.extract_text(x_tolerance=2, y_tolerance=2)
                if page_text:
                    pages.append(page_text)
            text = "\n\n".join(pages)
    except Exception as e:
        warnings.append(f"pdfplumber failed: {e}")

    if len(text.strip()) < 100:
        warnings.append("pdfplumber returned sparse text, falling back to PyMuPDF")
        try:
            doc = fitz.open(stream=file_bytes, filetype="pdf")
            pages = [page.get_text("text") for page in doc]
            doc.close()
            text = "\n\n".join(pages)
        except Exception as e:
            warnings.append(f"PyMuPDF also failed: {e}")

    if len(text.strip()) < 50:
        warnings.append("Very little text extracted - PDF may be image-only")

    return text.strip(), warnings


def extract_text_from_docx(file_bytes: bytes) -> Tuple[str, List[str]]:
    warnings: List[str] = []
    parts: List[str] = []
    try:
        doc = DocxDocument(io.BytesIO(file_bytes))
        for block in _iter_block_items(doc):
            if hasattr(block, "text"):
                t = block.text.strip()
                if t:
                    parts.append(t)
            else:
                for row in block.rows:
                    row_text = " | ".join(
                        cell.text.strip() for cell in row.cells if cell.text.strip()
                    )
                    if row_text:
                        parts.append(row_text)
    except Exception as e:
        warnings.append(f"DOCX extraction error: {e}")
    return "\n".join(parts), warnings


def _iter_block_items(doc):
    from docx.oxml.ns import qn
    parent = doc.element.body
    for child in parent.iterchildren():
        if child.tag == qn("w:p"):
            from docx.text.paragraph import Paragraph
            yield Paragraph(child, doc)
        elif child.tag == qn("w:tbl"):
            from docx.table import Table
            yield Table(child, doc)


def extract_text_from_txt(file_bytes: bytes) -> Tuple[str, List[str]]:
    for encoding in ("utf-8", "latin-1", "cp1252"):
        try:
            return file_bytes.decode(encoding).strip(), []
        except UnicodeDecodeError:
            continue
    return file_bytes.decode("utf-8", errors="replace").strip(), ["Encoding detection failed"]


def detect_format(filename: str, file_bytes: bytes) -> FileFormat:
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        return FileFormat.PDF
    if ext in (".docx", ".doc"):
        return FileFormat.DOCX
    if ext in (".txt", ".text"):
        return FileFormat.TXT
    if file_bytes[:4] == b"%PDF":
        return FileFormat.PDF
    if file_bytes[:2] == b"PK":
        return FileFormat.DOCX
    return FileFormat.TXT


# ── LLM Structurer ────────────────────────────────────────────────────────────

def _clean_llm_json(raw: str) -> str:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
    return raw.strip()


def structure_with_llm(raw_text: str) -> Tuple[dict, List[str]]:
    warnings: List[str] = []

    if not settings.anthropic_api_key or settings.anthropic_api_key == "your_anthropic_api_key_here":
        warnings.append("No Anthropic API key - using regex fallback extraction")
        return _regex_fallback(raw_text), warnings

    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    words = raw_text.split()
    if len(words) > 6000:
        raw_text = " ".join(words[:6000])
        warnings.append("Resume truncated to 6000 words for LLM processing")

    try:
        message = client.messages.create(
            model=settings.llm_model,
            max_tokens=settings.llm_max_tokens,
            system=EXTRACTION_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": EXTRACTION_USER_PROMPT.format(raw_text=raw_text)}],
        )
        raw_json = message.content[0].text
        cleaned = _clean_llm_json(raw_json)
        return json.loads(cleaned), warnings
    except json.JSONDecodeError as e:
        warnings.append(f"LLM returned invalid JSON ({e}), using regex fallback")
        return _regex_fallback(raw_text), warnings
    except anthropic.APIError as e:
        warnings.append(f"Anthropic API error ({e}), using regex fallback")
        return _regex_fallback(raw_text), warnings


def _regex_fallback(text: str) -> dict:
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[a-z]{2,}", text, re.I)
    phone_match = re.search(r"(\+?\d[\d\s\-().]{7,}\d)", text)
    linkedin_match = re.search(r"linkedin\.com/in/[\w\-]+", text, re.I)
    github_match = re.search(r"github\.com/[\w\-]+", text, re.I)

    skills_raw: List[str] = []
    skill_section = re.search(
        r"(?:skills?|technical skills?|core competenc)[:\s]*(.*?)(?:\n\n|\Z)", text, re.I | re.S
    )
    if skill_section:
        skills_raw = [
            s.strip(" *-|,")
            for s in re.split(r"[,\n|*]", skill_section.group(1))
            if 1 < len(s.strip()) < 60
        ]

    name = ""
    for line in text.splitlines():
        line = line.strip()
        if line and not re.search(r"[@./]", line) and 2 < len(line) < 60:
            name = line
            break

    return {
        "full_name": name,
        "email": email_match.group(0) if email_match else "",
        "phone": phone_match.group(0).strip() if phone_match else "",
        "location": "",
        "linkedin_url": f"https://{linkedin_match.group(0)}" if linkedin_match else "",
        "github_url": f"https://{github_match.group(0)}" if github_match else "",
        "portfolio_url": "",
        "summary": "",
        "total_years_experience": None,
        "work_experience": [],
        "education": [],
        "skills": [{"raw_name": s, "proficiency": None, "years_experience": None, "context_snippet": ""} for s in skills_raw[:40]],
        "certifications": [],
        "projects": [],
        "publications": [],
        "languages": [],
    }


# ── Model Builder ─────────────────────────────────────────────────────────────

def _safe_proficiency(value) -> Optional[ProficiencyLevel]:
    if not value:
        return None
    try:
        return ProficiencyLevel(str(value).lower())
    except ValueError:
        return None


def _estimate_confidence(structured: dict) -> float:
    score = 0.0
    if structured.get("full_name"):
        score += 0.2
    if structured.get("email"):
        score += 0.1
    if structured.get("work_experience"):
        score += 0.3
    if structured.get("education"):
        score += 0.15
    if structured.get("skills"):
        score += 0.25
    return round(min(score, 1.0), 2)


def build_parsed_resume(structured, source_format, source_filename, raw_text, warnings, parse_start) -> ParsedResume:
    work_exp = [
        WorkExperience(
            company=w.get("company", ""),
            role=w.get("role", ""),
            start_date=w.get("start_date"),
            end_date=w.get("end_date"),
            duration_months=w.get("duration_months"),
            responsibilities=w.get("responsibilities", []),
            technologies=w.get("technologies", []),
        )
        for w in structured.get("work_experience", [])
    ]
    education = [
        Education(
            institution=e.get("institution", ""),
            degree=e.get("degree", ""),
            field=e.get("field", ""),
            year=e.get("year"),
            gpa=e.get("gpa"),
        )
        for e in structured.get("education", [])
    ]
    skills = [
        ExtractedSkill(
            raw_name=s.get("raw_name", ""),
            proficiency=_safe_proficiency(s.get("proficiency")),
            years_experience=s.get("years_experience"),
            context_snippet=s.get("context_snippet", "")[:120],
        )
        for s in structured.get("skills", [])
        if s.get("raw_name", "").strip()
    ]
    certifications = [
        Certification(
            name=c.get("name", ""),
            issuer=c.get("issuer", ""),
            year=c.get("year"),
            expiry_year=c.get("expiry_year"),
        )
        for c in structured.get("certifications", [])
    ]
    projects = [
        Project(
            name=p.get("name", ""),
            description=p.get("description", ""),
            technologies=p.get("technologies", []),
            url=p.get("url"),
        )
        for p in structured.get("projects", [])
    ]
    return ParsedResume(
        full_name=structured.get("full_name", ""),
        email=structured.get("email") or None,
        phone=structured.get("phone") or None,
        location=structured.get("location") or None,
        linkedin_url=structured.get("linkedin_url") or None,
        github_url=structured.get("github_url") or None,
        portfolio_url=structured.get("portfolio_url") or None,
        summary=structured.get("summary", ""),
        total_years_experience=structured.get("total_years_experience"),
        work_experience=work_exp,
        education=education,
        skills=skills,
        certifications=certifications,
        projects=projects,
        publications=structured.get("publications", []),
        languages=structured.get("languages", []),
        source_format=source_format,
        source_filename=source_filename,
        raw_text_length=len(raw_text),
        parse_confidence=_estimate_confidence(structured),
        parse_warnings=warnings,
    )


# ── Public API ────────────────────────────────────────────────────────────────

class ParsingAgent:
    def parse_file(self, file_bytes: bytes, filename: str) -> ParsedResume:
        t0 = time.perf_counter()
        warnings: List[str] = []
        fmt = detect_format(filename, file_bytes)

        if fmt == FileFormat.PDF:
            raw_text, w = extract_text_from_pdf(file_bytes)
        elif fmt == FileFormat.DOCX:
            raw_text, w = extract_text_from_docx(file_bytes)
        else:
            raw_text, w = extract_text_from_txt(file_bytes)
        warnings.extend(w)

        logger.info("Text extracted", extra={"filename": filename, "format": fmt, "chars": len(raw_text)})

        structured, llm_warnings = structure_with_llm(raw_text)
        warnings.extend(llm_warnings)

        resume = build_parsed_resume(structured, fmt, filename, raw_text, warnings, t0)
        logger.info("Resume parsed", extra={"candidate_id": resume.id, "confidence": resume.parse_confidence})
        return resume

    def parse_text(self, text: str, filename: str = "resume.txt") -> ParsedResume:
        return self.parse_file(text.encode("utf-8"), filename)


parsing_agent = ParsingAgent()
