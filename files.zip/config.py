from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import List


class Settings(BaseSettings):
    # Anthropic
    anthropic_api_key: str = ""

    # Database
    database_url: str = "postgresql://user:password@localhost:5432/talent_intel"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # ChromaDB
    chroma_persist_dir: str = "./chroma_db"

    # Security
    secret_key: str = "change_this_in_production"
    api_key_header: str = "X-API-Key"

    # App
    debug: bool = False
    log_level: str = "INFO"
    max_file_size_mb: int = 10
    allowed_origins: List[str] = ["http://localhost:3000", "http://localhost:8000"]

    # LLM model
    llm_model: str = "claude-3-5-sonnet-20241022"
    llm_max_tokens: int = 4096

    # Embedding model
    embedding_model: str = "all-MiniLM-L6-v2"

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    return Settings()
