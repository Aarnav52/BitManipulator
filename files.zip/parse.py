"""Parse routes — POST /api/v1/parse, /api/v1/parse/text, /api/v1/parse/batch"""
import uuid, time
from typing import List
from fastapi import APIRouter, UploadFile, File, Depends, BackgroundTasks, HTTPException
from api.dependencies import verify_api_key, validate_resume_file
from models.resume import ParsedResume, ParseRequest, BatchParseResponse, BatchJobStatus

router = APIRouter(prefix="/api/v1/parse", tags=["Resume Parsing"])
_batch_jobs: dict = {}


@router.post("", response_model=ParsedResume, summary="Parse a single resume file")
async def parse_resume(
    file: UploadFile = File(..., description="PDF, DOCX, or TXT resume"),
    _: str = Depends(verify_api_key),
):
    """Upload a resume and receive a fully structured, skill-normalized candidate profile."""
    from agents.orchestrator import orchestrator
    content = await validate_resume_file(file)
    return orchestrator.process_resume(content, file.filename or "resume")


@router.post("/text", response_model=ParsedResume, summary="Parse plain-text resume")
async def parse_text_resume(body: ParseRequest, _: str = Depends(verify_api_key)):
    """Submit raw resume text (no file upload)."""
    from agents.orchestrator import orchestrator
    return orchestrator.process_resume(body.text.encode("utf-8"), body.filename)


@router.post("/batch", response_model=BatchParseResponse, status_code=202, summary="Batch parse (async)")
async def batch_parse(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    _: str = Depends(verify_api_key),
):
    """Upload up to 50 resumes. Returns a job_id — poll GET /api/v1/parse/batch/{job_id}."""
    if len(files) > 50:
        raise HTTPException(status_code=400, detail="Maximum 50 files per batch")
    job_id    = str(uuid.uuid4())
    file_data = [(await f.read(), f.filename or "resume") for f in files]
    _batch_jobs[job_id] = {
        "status": "queued", "total": len(file_data),
        "completed": 0, "failed_count": 0, "results": [],
        "created_at": time.time(), "completed_at": None,
    }
    background_tasks.add_task(_process_batch, job_id, file_data)
    return BatchParseResponse(
        job_id=job_id, status="queued", total_files=len(file_data),
        message=f"Batch queued ({len(file_data)} files). Poll GET /api/v1/parse/batch/{job_id}.",
    )


@router.get("/batch/{job_id}", response_model=BatchJobStatus, summary="Poll batch job status")
async def get_batch_status(job_id: str, _: str = Depends(verify_api_key)):
    if job_id not in _batch_jobs:
        raise HTTPException(status_code=404, detail="Batch job not found")
    from datetime import datetime
    j = _batch_jobs[job_id]
    return BatchJobStatus(
        job_id=job_id, status=j["status"], total=j["total"],
        completed=j["completed"], failed_count=j["failed_count"], results=j["results"],
        created_at=datetime.fromtimestamp(j["created_at"]),
        completed_at=datetime.fromtimestamp(j["completed_at"]) if j["completed_at"] else None,
    )


async def _process_batch(job_id: str, file_data: list):
    from agents.orchestrator import orchestrator
    j = _batch_jobs[job_id]
    j["status"] = "processing"
    for content, filename in file_data:
        try:
            result = orchestrator.process_resume(content, filename)
            j["results"].append(result)
        except Exception as e:
            j["failed_count"] += 1
        j["completed"] += 1
    j["status"] = "done"
    j["completed_at"] = time.time()
